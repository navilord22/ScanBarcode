abstract class BlocBase {
  void dispose();
}
